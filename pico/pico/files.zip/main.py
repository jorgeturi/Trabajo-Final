# La Pi decide todo. La Pico: muestra, saca PWM y marca falla si la Pi no habla.
from machine import Pin, WDT
from time import ticks_ms, ticks_add, ticks_diff, sleep_ms
import config as C
import estados as E
from salidas import Motores, Buzzer
from pantalla import Pantalla

def main():
    now = ticks_ms()
    if C.MODO == "PI":
        from enlace import EnlacePi
        fuente = EnlacePi()
    else:
        from simulador import Simulador
        fuente = Simulador(now)

    motores, buzzer, pantalla = Motores(), Buzzer(), Pantalla()
    led = Pin(C.PIN_LED, Pin.OUT)
    wdt = WDT(timeout=C.WDT_MS) if C.USAR_WDT else None
    proximo = ticks_add(now, C.LOOP_MS)
    t_led = now

    while True:
        now = ticks_ms()
        fuente.poll(now)

        ok = fuente.enlace_ok(now)
        if ok:
            est, mask, pl, pr = fuente.estado, fuente.mascara, fuente.pwm_l, fuente.pwm_r
        else:                                    # sin datos de la Pi: PWM a 0 y falla
            est, mask, pl, pr = 0, 0, 0, 0

        motores.set(pl, pr)
        buzzer.actualizar(now, 2 if (not ok or est == E.EMERGENCIA) else (1 if mask else 0))
        pantalla.actualizar(now, ok, est, mask, pl, pr)

        if ticks_diff(now, t_led) >= 500:
            led.toggle(); t_led = now
        if wdt:
            wdt.feed()
        d = ticks_diff(proximo, ticks_ms())
        if d > 0:
            sleep_ms(d)
            proximo = ticks_add(proximo, C.LOOP_MS)
        else:
            proximo = ticks_add(ticks_ms(), C.LOOP_MS)

main()
